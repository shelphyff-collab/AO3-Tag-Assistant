chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "extract_tags",
    title: "提取当前页面标签 (Extract Tags)",
    contexts: ["page"],
    documentUrlPatterns: ["*://archiveofourown.org/works/*", "*://*.archiveofourown.org/works/*"]
  });
  
  chrome.contextMenus.create({
    id: "fill_tags_parent",
    title: "填入标签模板 (Fill Tags)",
    contexts: ["page"],
    documentUrlPatterns: ["*://archiveofourown.org/works/new", "*://archiveofourown.org/works/*/edit", "*://*.archiveofourown.org/works/new", "*://*.archiveofourown.org/works/*/edit"]
  });
  
  updateFillMenu();
});

function updateFillMenu() {
  chrome.storage.local.get(['ao3Templates'], (res) => {
    const templates = res.ao3Templates || [];
    
    // Use try/catch to avoid errors if parent doesn't exist
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: "extract_tags",
        title: "提取当前页面标签 (Extract Tags)",
        contexts: ["page"],
        documentUrlPatterns: ["*://archiveofourown.org/works/*", "*://*.archiveofourown.org/works/*"]
      });
      
      chrome.contextMenus.create({
        id: "fill_tags_parent",
        title: "填入标签模板 (Fill Tags)",
        contexts: ["page"],
        documentUrlPatterns: ["*://archiveofourown.org/works/new", "*://archiveofourown.org/works/*/edit", "*://*.archiveofourown.org/works/new", "*://*.archiveofourown.org/works/*/edit"]
      });
      
      if (templates.length === 0) {
        chrome.contextMenus.create({
          id: "no_templates",
          parentId: "fill_tags_parent",
          title: "无可用模板 (No templates)",
          contexts: ["page"],
          enabled: false
        });
      } else {
        templates.forEach(t => {
          chrome.contextMenus.create({
            id: `fill_template_${t.id}`,
            parentId: "fill_tags_parent",
            title: t.name,
            contexts: ["page"]
          });
        });
      }
    });
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.ao3Templates) {
    updateFillMenu();
  }
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab) return;
  if (info.menuItemId === "extract_tags") {
    extractAndSaveTags(tab.id);
  } else if (info.menuItemId.toString().startsWith("fill_template_")) {
    const templateId = info.menuItemId.replace("fill_template_", "");
    fillTagsByTemplateId(tab.id, templateId);
  }
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (!tab || !tab.url.includes("archiveofourown.org/works")) return;
  if (command === "extract_tags") {
    extractAndSaveTags(tab.id);
  }
});

function extractAndSaveTags(tabId) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: () => {
      return {
        rating: Array.from(document.querySelectorAll('dd.rating.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        warnings: Array.from(document.querySelectorAll('dd.warning.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        categories: Array.from(document.querySelectorAll('dd.category.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        fandoms: Array.from(document.querySelectorAll('dd.fandom.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        relationships: Array.from(document.querySelectorAll('dd.relationship.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        characters: Array.from(document.querySelectorAll('dd.character.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : ''),
        additionalTags: Array.from(document.querySelectorAll('dd.freeform.tags ul.commas li a')).map(el => el.textContent ? el.textContent.trim() : '')
      };
    }
  }, (results) => {
    if (chrome.runtime.lastError || !results || !results[0].result) {
      showToast(tabId, '提取失败：未能读取页面数据。');
      return;
    }
    
    const data = results[0].result;
    const hasTags = Object.values(data).some(val => Array.isArray(val) ? val.length > 0 : !!val);
    
    if (hasTags) {
      chrome.storage.local.get(['ao3Templates'], (res) => {
        const templates = res.ao3Templates || [];
        const newTemplate = {
          id: crypto.randomUUID(),
          name: `快捷提取 ${new Date().toLocaleTimeString()}`,
          rating: data.rating?.[0] || '',
          warnings: data.warnings || [],
          categories: data.categories || [],
          fandoms: data.fandoms || [],
          relationships: data.relationships || [],
          characters: data.characters || [],
          additionalTags: data.additionalTags || [],
          language: '中文-普通话',
          privacy: { apply: false, restricted: false, moderated: false, commentSettings: '' },
          preface: { apply: false, position: 'none', content: '' }
        };
        templates.push(newTemplate);
        chrome.storage.local.set({ ao3Templates: templates }, () => {
            showToast(tabId, '✅ 标签提取成功并已保存！可打开扩展面板查看和编辑。');
        });
      });
    } else {
      showToast(tabId, '❌ 提取失败：此页面未找到任何标签。');
    }
  });
}

function showToast(tabId, message) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: (msg) => alert(msg),
    args: [message]
  });
}

function fillTagsByTemplateId(tabId, templateId) {
  chrome.storage.local.get(['ao3Templates'], (res) => {
    const templates = res.ao3Templates || [];
    const template = templates.find(t => t.id === templateId);
    if (template) {
      chrome.tabs.sendMessage(tabId, { action: 'fill', template }, (response) => {
        if (chrome.runtime.lastError) {
          showToast(tabId, '❌ 填入失败：插件脚本未就绪，请刷新页面后再试。');
        } else {
          showToast(tabId, `✅ 成功填入模板: ${template.name}`);
        }
      });
    }
  });
}
