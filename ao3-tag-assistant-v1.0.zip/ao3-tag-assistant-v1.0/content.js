// content.js
// This script runs on AO3 pages.

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extract') {
    const data = {
      rating: getTags('.rating.tags .tag, span.rating, .rating.tags a'),
      warnings: getTags('.warning.tags .tag, li.warnings .tag, .warning.tags a'),
      categories: getTags('.category.tags .tag, span.category, .category.tags a'),
      fandoms: getTags('.fandom.tags .tag, h5.fandoms .tag, .fandom.tags a'),
      relationships: getTags('.relationship.tags .tag, li.relationships .tag, .relationship.tags a'),
      characters: getTags('.character.tags .tag, li.characters .tag, .character.tags a'),
      additionalTags: getTags('.freeform.tags .tag, li.freeforms .tag, .freeform.tags a')
    };
    sendResponse(data);
  } else if (request.action === 'fill') {
    const { template } = request;
    
    // Fill Rating
    if (template.rating) {
      const ratingSelect = document.getElementById('work_rating_string') || document.querySelector('select[name="work[rating_string]"]');
      if (ratingSelect) {
        Array.from(ratingSelect.options).forEach(opt => {
          if (opt.text.toLowerCase() === template.rating.toLowerCase()) {
            ratingSelect.value = opt.value;
            ratingSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }
        });
      }
    }

    // Fill Checkboxes (Warnings, Categories)
    const fillCheckboxes = (values, namePattern) => {
      const checkboxes = document.querySelectorAll(`input[type="checkbox"][name*="${namePattern}"]`);
      
      // 先取消所有已勾选的选项
      checkboxes.forEach(cb => {
        if (cb.checked) {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });

      if (!values || values.length === 0) return;

      // 然后仅勾选模板中包含的选项
      checkboxes.forEach(cb => {
        const labelEl = cb.parentElement;
        const labelText = labelEl ? labelEl.textContent.trim().toLowerCase() : '';
        if (!labelText) return;
        
        const isMatch = values.some(v => {
          const val = v.toLowerCase().trim();
          if (!val) return false;
          
          // 精确匹配
          if (val === labelText) return true;
          
          // AO3 特殊情况：Creator Chose Not To Use Archive Warnings
          if (val === 'creator chose not to use archive warnings' && labelText === 'choose not to use archive warnings') return true;
          if (labelText === 'creator chose not to use archive warnings' && val === 'choose not to use archive warnings') return true;
          
          return false;
        });

        if (isMatch) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    };

    fillCheckboxes(template.warnings, 'archive_warning_strings');
    fillCheckboxes(template.categories, 'category_strings');

    // Fill Text Inputs
    const fillInputByName = (values, name) => {
        if (!values || values.length === 0) return;
        const input = document.querySelector(`input[name="${name}"]`);
        if (input) {
            // 获取已有值并去重
            const existingValue = input.value || '';
            const existingTags = existingValue.split(',').map(t => t.trim()).filter(Boolean);
            const uniqueNewTags = values.filter(v => !existingTags.some(e => e.toLowerCase() === v.toLowerCase()));
            
            if (uniqueNewTags.length === 0) return; // 没有新标签需要添加

            const mergedTags = [...existingTags, ...uniqueNewTags];
            const textValue = mergedTags.join(', ');
            
            // 设置隐藏的原始输入框
            input.value = textValue;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));

            // 查找 AO3 自动生成的可见输入框 (id 以 _autocomplete 结尾)
            const autocompleteInput = document.getElementById(input.id + '_autocomplete');
            if (autocompleteInput) {
                autocompleteInput.focus();
                
                // 逐个填入新的 tag 并模拟按下逗号进行分词
                uniqueNewTags.forEach(tag => {
                    autocompleteInput.value = tag;
                    autocompleteInput.dispatchEvent(new Event('input', { bubbles: true }));
                    
                    autocompleteInput.dispatchEvent(new KeyboardEvent('keydown', {
                        key: ',',
                        code: 'Comma',
                        keyCode: 188,
                        which: 188,
                        bubbles: true
                    }));
                });
                
                autocompleteInput.blur();
                
                // 确保原始输入框保留了完整的值
                setTimeout(() => {
                    input.value = textValue;
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                }, 100);
            }
        }
    }
    
    fillInputByName(template.fandoms, 'work[fandom_string]');
    fillInputByName(template.relationships, 'work[relationship_string]');
    fillInputByName(template.characters, 'work[character_string]');
    fillInputByName(template.additionalTags, 'work[freeform_string]');

    // Fill Language
    if (template.language) {
      const langSelect = document.querySelector('select[name="work[language_id]"]');
      if (langSelect) {
        Array.from(langSelect.options).forEach(opt => {
          if (opt.text.includes(template.language)) {
            langSelect.value = opt.value;
            langSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }
        });
      }
    }

    // Fill Privacy
    if (template.privacy && template.privacy.apply) {
      const restrictedCb = document.querySelector('input[name="work[restricted]"]');
      if (restrictedCb) {
        restrictedCb.checked = template.privacy.restricted;
        restrictedCb.dispatchEvent(new Event('change', { bubbles: true }));
      }
      
      const moderatedCb = document.querySelector('input[name="work[moderated]"]');
      if (moderatedCb) {
        moderatedCb.checked = template.privacy.moderated;
        moderatedCb.dispatchEvent(new Event('change', { bubbles: true }));
      }

      if (template.privacy.commentSettings) {
        const labels = document.querySelectorAll('label');
        labels.forEach(label => {
          let match = false;
          if (template.privacy.commentSettings === 'all' && label.textContent.includes('Registered users and guests can comment')) match = true;
          if (template.privacy.commentSettings === 'registered' && label.textContent.includes('Only registered users can comment')) match = true;
          if (template.privacy.commentSettings === 'none' && label.textContent.includes('No one can comment')) match = true;
          
          if (match) {
            const radioId = label.getAttribute('for');
            if (radioId) {
              const radio = document.getElementById(radioId);
              if (radio) {
                radio.checked = true;
                radio.dispatchEvent(new Event('change', { bubbles: true }));
              }
            }
          }
        });
      }
    }

    // Fill Preface Notes
    if (template.preface && template.preface.apply && template.preface.position !== 'none') {
      const isBeginning = template.preface.position === 'beginning';
      const isEnd = template.preface.position === 'end';
      
      const labels = document.querySelectorAll('label');
      let startCbId = null;
      let endCbId = null;
      
      labels.forEach(label => {
        if (label.textContent.includes('at the beginning')) startCbId = label.getAttribute('for');
        if (label.textContent.includes('at the end')) endCbId = label.getAttribute('for');
      });
      
      if (isBeginning && startCbId) {
        const cb = document.getElementById(startCbId);
        if (cb && !cb.checked) {
          cb.click();
        }
        setTimeout(() => {
          const ta = document.querySelector('textarea[name="work[notes]"]');
          if (ta) {
            ta.value = template.preface.content;
            ta.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }, 100);
      }
      
      if (isEnd && endCbId) {
        const cb = document.getElementById(endCbId);
        if (cb && !cb.checked) {
          cb.click();
        }
        setTimeout(() => {
          const ta = document.querySelector('textarea[name="work[endnotes]"]');
          if (ta) {
            ta.value = template.preface.content;
            ta.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }, 100);
      }
    }

    sendResponse({ success: true });
  }
  return true; // Keep message channel open for async
});

function getTags(selector) {
  const elements = document.querySelectorAll(selector);
  return Array.from(elements).map(el => el.textContent.trim()).filter(Boolean);
}
